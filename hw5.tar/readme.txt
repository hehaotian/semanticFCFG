HW 5 LING 571
HAOTIAN HE
====================

Frankly, this homework is much easier than the last one, as there are no question sentences and other tricky things involved.

The hard parts in this homework like AuxP and Neg are almost the same as the last homework, and I simply took a look back at the previous one to convert them to a semantic version.

Another part attracted my attention is the treatment of the conjunction and disjunction. The way I dealt with it in the function-argument approach is to create a rule like <?conj(?v1, ?v2)>. I once wanted to do like this <?v1(?conj, ?v2)>, but soon realized the first one is better.

====================

During doing the homework, I referred to the webpage (https://code.google.com/p/nltk/source/browse/trunk/nltk/examples/grammars/book_grammars/simple-sem.fcfg?r=8149) for the Semantic FCFG sample, which helped me a lot to both finish and understand Semantic FCFG.