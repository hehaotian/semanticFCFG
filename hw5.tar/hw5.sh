#!/bin/bash

# LING571 HW5
# Haotian He

python2.7 hw5.py $@